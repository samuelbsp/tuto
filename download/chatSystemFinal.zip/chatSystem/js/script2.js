$(document).ready(function(){
    var hauteur = window.innerHeight;
    $('#chatLineHolder').css('height',hauteur-130);
    $('#chatUsers').css('min-height',hauteur-10);
});